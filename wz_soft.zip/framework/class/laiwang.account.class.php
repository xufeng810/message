<?php
/**
 * [WECHAT 2017]
 
 */
defined('IN_IA') or exit('Access Denied');

class WeAccount {
	
	public function __construct() {
	}

}
